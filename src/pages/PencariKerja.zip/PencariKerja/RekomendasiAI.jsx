import { useState, useEffect, useContext } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { matchingService } from '../../services/matchingService';
import { applicationService } from '../../services/applicationService';
import { NotificationContext } from '../../contexts/NotificationContext';
import { formatSalaryRange } from '../../utils/formatNumber';
import Badge from '../../components/common/Badge';
import EmptyState from '../../components/common/EmptyState';
import { Sparkles, Building2, MapPin, CheckCircle, AlertTriangle, ArrowRight, BookOpen, Send } from 'lucide-react';

export function RekomendasiAI() {
  const { user } = useAuth();
  const notify = useContext(NotificationContext);

  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.id) {
      loadRecommendations();
    }
  }, [user]);

  const loadRecommendations = async () => {
    setLoading(true);
    try {
      const data = await matchingService.getRecommendationsForCandidate(user.id);
      setRecommendations(data);
    } catch {
      notify?.error('Gagal menghitung rekomendasi AI.');
    } finally {
      setLoading(false);
    }
  };

  const handleApply = async (job) => {
    try {
      await applicationService.applyJob({
        jobId: job.id,
        jobTitle: job.title,
        companyId: job.companyId,
        companyName: job.companyName,
        applicantId: user.id,
        applicantName: user.name,
        applicantEmail: user.email,
        applicantPhone: user.phone,
        matchScore: job.matchScore,
        coverLetter: 'Mengajukan lamaran melalui rekomendasi cerdas AI Smart Matching KarirKu.'
      });
      notify?.success(`Lamaran untuk ${job.title} berhasil diajukan!`);
    } catch (err) {
      notify?.error(err.message || 'Gagal mengajukan lamaran.');
    }
  };

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
          <div style={{ background: '#eef2ff', padding: '6px', borderRadius: '8px', color: '#4f46e5' }}>
            <Sparkles size={22} />
          </div>
          <h1 style={{ fontSize: '1.65rem', fontWeight: 800, color: '#0f172a' }}>
            Rekomendasi Cerdas AI (Smart Matching)
          </h1>
        </div>
        <p style={{ color: '#64748b', fontSize: '0.88rem' }}>
          Daftar lowongan kerja yang diurutkan secara matematis berdasarkan tingkat kecocokan profil kompetensi, pendidikan, dan pengalaman Anda.
        </p>
      </div>

      {recommendations.length === 0 && !loading ? (
        <EmptyState
          title="Belum Ada Rekomendasi"
          description="Lengkapi riwayat pendidikan dan keahlian pada menu profil Anda untuk mengaktifkan kalkulasi smart matching."
        />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
          {recommendations.map((job) => (
            <div key={job.id} className="card card-hoverable" style={{ borderLeft: job.matchScore >= 85 ? '4px solid #10b981' : '4px solid #8b5cf6' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px' }}>
                <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
                  <img
                    src={job.companyLogo || 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?auto=format&fit=crop&w=100&q=80'}
                    alt={job.companyName}
                    style={{ width: '56px', height: '56px', borderRadius: '12px', objectFit: 'cover' }}
                  />
                  <div>
                    <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: '#0f172a' }}>{job.title}</h3>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#64748b', fontSize: '0.85rem' }}>
                      <Building2 size={14} /> <strong>{job.companyName}</strong> • <MapPin size={14} /> {job.location} ({job.workplaceType})
                    </div>
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '1.6rem', fontWeight: 800, color: job.matchScore >= 85 ? '#059669' : '#4f46e5', lineHeight: 1 }}>
                      {job.matchScore}%
                    </div>
                    <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748b' }}>
                      {job.matchGrade}
                    </div>
                  </div>
                  <button onClick={() => handleApply(job)} className="btn btn-primary btn-sm">
                    <Send size={15} /> Lamar Posisi
                  </button>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="match-progress-bar" style={{ margin: '14px 0 10px', height: '8px' }}>
                <div
                  className={`match-progress-fill ${job.matchScore >= 85 ? 'high' : ''}`}
                  style={{ width: `${job.matchScore}%` }}
                />
              </div>

              {/* Salary & Details */}
              <div style={{ fontSize: '0.9rem', fontWeight: 700, color: '#059669', marginBottom: '12px' }}>
                Estimasi Gaji: {formatSalaryRange(job.salaryMin, job.salaryMax)}
              </div>

              {/* Matched vs Missing Skills */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', background: '#f8fafc', padding: '14px', borderRadius: '8px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap', fontSize: '0.82rem' }}>
                  <span style={{ color: '#059669', fontWeight: 700 }}>✓ Keahlian Cocok ({job.matchedSkills?.length || 0}):</span>
                  {job.matchedSkills?.map((s, idx) => (
                    <span key={idx} style={{ background: '#ecfdf5', color: '#047857', padding: '2px 8px', borderRadius: '4px', fontWeight: 600 }}>
                      {s}
                    </span>
                  ))}
                </div>

                {job.missingSkills && job.missingSkills.length > 0 && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap', fontSize: '0.82rem' }}>
                    <span style={{ color: '#d97706', fontWeight: 700 }}>Saran Upskilling ({job.missingSkills.length}):</span>
                    {job.missingSkills.map((s, idx) => (
                      <span key={idx} style={{ background: '#fffbeb', color: '#b45309', padding: '2px 8px', borderRadius: '4px' }}>
                        {s}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default RekomendasiAI;
