import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { applicationService } from '../../services/applicationService';
import { matchingService } from '../../services/matchingService';
import StatCard from '../../components/common/StatCard';
import Badge from '../../components/common/Badge';
import JobCard from '../../components/cards/JobCard';
import { formatIndonesianDate } from '../../utils/formatDate';
import {
  Send,
  Calendar,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  Briefcase,
  UserCheck,
  FileText
} from 'lucide-react';

export function DashboardPencariKerja() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [applications, setApplications] = useState([]);
  const [recommendedJobs, setRecommendedJobs] = useState([]);
  const [interviews, setInterviews] = useState([]);
  const [profileCompletion, setProfileCompletion] = useState(85);

  useEffect(() => {
    if (user?.id) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    try {
      const myApps = await applicationService.getMyApplications(user.id);
      setApplications(myApps);

      const interviewList = myApps.filter((a) => a.status === 'Jadwal Wawancara');
      setInterviews(interviewList);

      const recJobs = await matchingService.getRecommendationsForCandidate(user.id);
      setRecommendedJobs(recJobs.slice(0, 3));
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    }
  };

  return (
    <div>
      {/* Welcome Hero Banner */}
      <div
        className="card mb-6"
        style={{
          background: 'linear-gradient(135deg, #312e81 0%, #4338ca 50%, #4f46e5 100%)',
          color: '#ffffff',
          padding: '32px',
          border: 'none',
          position: 'relative',
          overflow: 'hidden'
        }}
      >
        <div style={{ maxWidth: '640px', position: 'relative', zIndex: 2 }}>
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              padding: '4px 12px',
              borderRadius: '999px',
              background: 'rgba(255, 255, 255, 0.15)',
              fontSize: '0.78rem',
              fontWeight: 600,
              marginBottom: '14px'
            }}
          >
            <Sparkles size={14} /> AI Smart Career Navigator
          </div>
          <h1 style={{ fontSize: '1.85rem', fontWeight: 800, color: '#ffffff', marginBottom: '8px' }}>
            Halo, {user?.name || 'Pencari Kerja'}!
          </h1>
          <p style={{ color: '#e0e7ff', fontSize: '0.94rem', lineHeight: 1.5, marginBottom: '20px' }}>
            Profil Anda saat ini memiliki kecocokan tinggi dengan lowongan di sektor teknologi dan rekayasa perangkat lunak.
          </p>

          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
            <button onClick={() => navigate('/pencari-kerja/lowongan')} className="btn btn-secondary btn-sm" style={{ background: '#ffffff', color: '#4338ca', fontWeight: 700 }}>
              <Briefcase size={16} /> Eksplorasi Lowongan
            </button>
            <button onClick={() => navigate('/pencari-kerja/cv')} className="btn btn-outline btn-sm" style={{ color: '#ffffff', borderColor: 'rgba(255,255,255,0.4)' }}>
              <FileText size={16} /> Pratinjau CV ATS
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-4 mb-6">
        <StatCard
          title="Lamaran Terkirim"
          value={applications.length}
          icon={Send}
          subtext="Total riwayat pengajuan"
          iconBg="#eef2ff"
          iconColor="#4f46e5"
        />
        <StatCard
          title="Jadwal Wawancara"
          value={interviews.length}
          icon={Calendar}
          subtext="Undangan tahap lanjut"
          iconBg="#ecfdf5"
          iconColor="#10b981"
        />
        <StatCard
          title="Rekomendasi AI Cocok"
          value={recommendedJobs.length}
          icon={Sparkles}
          subtext="Match score > 80%"
          iconBg="#f5f3ff"
          iconColor="#8b5cf6"
        />
        <StatCard
          title="Kelengkapan Profil"
          value={`${profileCompletion}%`}
          icon={UserCheck}
          trend="Hampir Lengkap"
          trendType="positive"
          iconBg="#fffbeb"
          iconColor="#f59e0b"
        />
      </div>

      {/* Main Sections Grid */}
      <div className="grid grid-cols-3 mb-6">
        {/* Left: Recommended Jobs */}
        <div style={{ gridColumn: 'span 2', display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: '#0f172a', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Sparkles size={20} color="#6366f1" />
              <span>Lowongan Rekomendasi AI Terbaik untuk Anda</span>
            </h3>
            <button onClick={() => navigate('/pencari-kerja/rekomendasi')} className="btn btn-secondary btn-sm">
              Lihat Semua
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {recommendedJobs.map((job) => (
              <JobCard
                key={job.id}
                job={job}
                onViewDetail={() => navigate('/pencari-kerja/lowongan')}
                onApply={() => navigate('/pencari-kerja/lowongan')}
              />
            ))}
          </div>
        </div>

        {/* Right: Interviews & Profile Progress */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* Upcoming Interviews Card */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">
                <Calendar size={18} color="#10b981" />
                <span>Undangan Wawancara</span>
              </h3>
              <Badge variant="success">{interviews.length} Jadwal</Badge>
            </div>

            {interviews.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '24px 0', color: '#94a3b8', fontSize: '0.86rem' }}>
                Belum ada jadwal wawancara aktif.
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {interviews.map((app) => (
                  <div
                    key={app.id}
                    style={{
                      padding: '12px',
                      borderRadius: '8px',
                      background: '#ecfdf5',
                      border: '1px solid #a7f3d0'
                    }}
                  >
                    <div style={{ fontWeight: 700, color: '#065f46', fontSize: '0.9rem' }}>
                      {app.jobTitle}
                    </div>
                    <div style={{ fontSize: '0.8rem', color: '#047857' }}>{app.companyName}</div>
                    <div style={{ fontSize: '0.75rem', color: '#059669', marginTop: '6px', fontWeight: 600 }}>
                      Waktu: {formatIndonesianDate(app.interviewDate || app.appliedAt)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Profile Completeness Checklist */}
          <div className="card">
            <h4 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: '14px' }}>
              Checklist Kesiapan Karir
            </h4>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '0.85rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#059669' }}>
                <CheckCircle2 size={16} />
                <span>Biodata & Kontak Terisi Lengkap</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#059669' }}>
                <CheckCircle2 size={16} />
                <span>Riwayat Pendidikan Formal S1 Terverifikasi</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#059669' }}>
                <CheckCircle2 size={16} />
                <span>Portofolio & Pengalaman Terlampir</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#d97706' }}>
                <Sparkles size={16} />
                <span>Uji Kompetensi Tambahan (Disarankan)</span>
              </div>
            </div>

            <button
              onClick={() => navigate('/pencari-kerja/profil')}
              className="btn btn-outline btn-sm w-full mt-4"
            >
              Perbarui Kelengkapan Profil
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DashboardPencariKerja;
