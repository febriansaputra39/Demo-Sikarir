import { useState, useEffect, useContext } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { jobService } from '../../services/jobService';
import { applicationService } from '../../services/applicationService';
import { matchingService } from '../../services/matchingService';
import { NotificationContext } from '../../contexts/NotificationContext';
import { formatSalaryRange } from '../../utils/formatNumber';
import { formatIndonesianDate } from '../../utils/formatDate';
import JobCard from '../../components/cards/JobCard';
import Modal from '../../components/common/Modal';
import Badge from '../../components/common/Badge';
import EmptyState from '../../components/common/EmptyState';
import { Search, Filter, MapPin, Building2, Send, Sparkles, CheckCircle2 } from 'lucide-react';

export function Lowongan() {
  const { user } = useAuth();
  const notify = useContext(NotificationContext);

  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [category, setCategory] = useState('Semua');
  const [jobType, setJobType] = useState('Semua');

  // Modals
  const [selectedJob, setSelectedJob] = useState(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isApplyOpen, setIsApplyOpen] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchJobs();
  }, [category, jobType]);

  const fetchJobs = async () => {
    setLoading(true);
    try {
      const data = await jobService.getAllJobs({
        onlyActive: true,
        category,
        jobType,
        search: searchTerm
      });

      // Calculate AI match scores for candidate
      if (user?.id) {
        const enriched = data.map((j) => {
          const match = matchingService.calculateMatch(user, j);
          return {
            ...j,
            matchScore: match.score,
            matchGrade: match.grade
          };
        });
        setJobs(enriched);
      } else {
        setJobs(data);
      }
    } catch {
      notify?.error('Gagal memuat data lowongan.');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    fetchJobs();
  };

  const handleToggleBookmark = (jobId) => {
    const isNowSaved = jobService.toggleBookmark(jobId, user.id);
    notify?.info(isNowSaved ? 'Lowongan disimpan ke daftar favorit.' : 'Lowongan dihapus dari tersimpan.');
    fetchJobs();
  };

  const handleOpenApply = (job) => {
    setSelectedJob(job);
    setIsDetailOpen(false);
    setIsApplyOpen(true);
  };

  const handleSubmitApplication = async (e) => {
    e.preventDefault();
    if (!selectedJob) return;

    setSubmitting(true);
    try {
      await applicationService.applyJob({
        jobId: selectedJob.id,
        jobTitle: selectedJob.title,
        companyId: selectedJob.companyId,
        companyName: selectedJob.companyName,
        applicantId: user.id,
        applicantName: user.name,
        applicantEmail: user.email,
        applicantPhone: user.phone,
        matchScore: selectedJob.matchScore || 85,
        coverLetter
      });

      notify?.success(`Lamaran untuk posisi "${selectedJob.title}" berhasil dikirim!`);
      setIsApplyOpen(false);
      setCoverLetter('');
    } catch (err) {
      notify?.error(err.message || 'Gagal mengajukan lamaran.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: '24px' }}>
        <h1 style={{ fontSize: '1.65rem', fontWeight: 800, color: '#0f172a' }}>
          Eksplorasi Lowongan Kerja
        </h1>
        <p style={{ color: '#64748b', fontSize: '0.88rem' }}>
          Temukan lowongan terverifikasi yang cocok dengan kompetensi dan preferensi karir Anda.
        </p>
      </div>

      {/* Filter Card */}
      <div className="card mb-6" style={{ padding: '18px 22px' }}>
        <form onSubmit={handleSearch} style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', alignItems: 'center' }}>
          <div style={{ flex: 1, minWidth: '240px', position: 'relative' }}>
            <Search size={18} color="#94a3b8" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
            <input
              type="text"
              className="form-input"
              style={{ paddingLeft: '38px' }}
              placeholder="Cari lowongan berdasarkan posisi, kata kunci, atau perusahaan..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div style={{ width: '180px' }}>
            <select className="form-select" value={category} onChange={(e) => setCategory(e.target.value)}>
              <option value="Semua">Semua Bidang</option>
              <option value="IT & Software">IT & Software</option>
              <option value="Data & AI">Data & AI</option>
              <option value="Desain Grafis & UI/UX">Desain Grafis</option>
              <option value="Pemasaran">Pemasaran</option>
            </select>
          </div>

          <div style={{ width: '160px' }}>
            <select className="form-select" value={jobType} onChange={(e) => setJobType(e.target.value)}>
              <option value="Semua">Semua Tipe</option>
              <option value="Full Time">Full Time</option>
              <option value="Contract">Contract</option>
              <option value="Internship">Internship</option>
            </select>
          </div>

          <button type="submit" className="btn btn-primary btn-sm">
            <Filter size={16} /> Cari Lowongan
          </button>
        </form>
      </div>

      {/* Grid of Job Cards */}
      {jobs.length === 0 && !loading ? (
        <EmptyState
          title="Tidak Ada Lowongan Ditemukan"
          description="Coba ubah kata kunci atau bersihkan filter pencarian Anda."
        />
      ) : (
        <div className="grid grid-cols-2">
          {jobs.map((job) => (
            <JobCard
              key={job.id}
              job={job}
              isSaved={jobService.isBookmarked(job.id, user?.id)}
              onToggleBookmark={handleToggleBookmark}
              onViewDetail={(j) => {
                setSelectedJob(j);
                setIsDetailOpen(true);
              }}
              onApply={handleOpenApply}
            />
          ))}
        </div>
      )}

      {/* Modal Detail Lowongan */}
      <Modal
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
        title="Detail Lengkap Lowongan Pekerjaan"
        size="lg"
      >
        {selectedJob && (
          <div>
            <div style={{ display: 'flex', gap: '16px', alignItems: 'center', marginBottom: '20px' }}>
              <img
                src={selectedJob.companyLogo || 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?auto=format&fit=crop&w=100&q=80'}
                alt={selectedJob.companyName}
                style={{ width: '56px', height: '56px', borderRadius: '12px', objectFit: 'cover' }}
              />
              <div>
                <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>{selectedJob.title}</h3>
                <div style={{ color: '#4f46e5', fontWeight: 600 }}>{selectedJob.companyName}</div>
                <div style={{ fontSize: '0.8rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <MapPin size={13} /> {selectedJob.location} • {selectedJob.jobType}
                </div>
              </div>
            </div>

            <div style={{ background: '#f8fafc', padding: '14px', borderRadius: '8px', marginBottom: '18px' }}>
              <div style={{ fontSize: '0.8rem', color: '#64748b' }}>Estimasi Gaji yang Ditawarkan:</div>
              <div style={{ fontSize: '1.15rem', fontWeight: 800, color: '#059669' }}>
                {formatSalaryRange(selectedJob.salaryMin, selectedJob.salaryMax)}
              </div>
            </div>

            <h4 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: '6px' }}>Deskripsi Pekerjaan:</h4>
            <p style={{ fontSize: '0.86rem', color: '#475569', lineHeight: 1.6, marginBottom: '18px' }}>
              {selectedJob.description}
            </p>

            <h4 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: '8px' }}>Tanggung Jawab Utama:</h4>
            <ul style={{ paddingLeft: '20px', fontSize: '0.86rem', color: '#475569', marginBottom: '18px' }}>
              {selectedJob.responsibilities?.map((item, idx) => (
                <li key={idx} style={{ marginBottom: '4px' }}>{item}</li>
              ))}
            </ul>

            <h4 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: '8px' }}>Keahlian yang Dibutuhkan:</h4>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '24px' }}>
              {selectedJob.requiredSkills?.map((skill, idx) => (
                <Badge key={idx} variant="primary">{skill}</Badge>
              ))}
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
              <button onClick={() => setIsDetailOpen(false)} className="btn btn-secondary">
                Tutup
              </button>
              <button onClick={() => handleOpenApply(selectedJob)} className="btn btn-primary">
                <Send size={16} /> Lamar Sekarang
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Modal Lamar Lowongan */}
      <Modal
        isOpen={isApplyOpen}
        onClose={() => setIsApplyOpen(false)}
        title="Konfirmasi Pengajuan Lamaran"
      >
        {selectedJob && (
          <form onSubmit={handleSubmitApplication}>
            <div style={{ marginBottom: '16px' }}>
              <div style={{ fontWeight: 700, fontSize: '1.05rem', color: '#1e293b' }}>{selectedJob.title}</div>
              <div style={{ color: '#4f46e5', fontSize: '0.85rem' }}>{selectedJob.companyName}</div>
            </div>

            <div style={{ background: '#eef2ff', padding: '12px', borderRadius: '8px', marginBottom: '16px', fontSize: '0.84rem', color: '#3730a3' }}>
              <Sparkles size={16} style={{ verticalAlign: 'middle', marginRight: '6px' }} />
              <strong>Skor Kecocokan AI Anda: {selectedJob.matchScore || 85}%</strong>
            </div>

            <div className="form-group">
              <label className="form-label">Surat Pengantar / Catatan Singkat (Cover Letter):</label>
              <textarea
                className="form-textarea"
                rows={4}
                placeholder="Jelaskan secara ringkas mengapa Anda adalah kandidat ideal untuk posisi ini..."
                value={coverLetter}
                onChange={(e) => setCoverLetter(e.target.value)}
              />
            </div>

            <div style={{ fontSize: '0.78rem', color: '#64748b', marginBottom: '20px' }}>
              * Berkas profil, riwayat pendidikan, dan portofolio keahlian Anda akan otomatis dikirimkan ke tim rekruter {selectedJob.companyName}.
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
              <button type="button" onClick={() => setIsApplyOpen(false)} className="btn btn-secondary">
                Batal
              </button>
              <button type="submit" disabled={submitting} className="btn btn-primary">
                {submitting ? 'Mengirimkan...' : 'Kirim Lamaran'}
              </button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}

export default Lowongan;
