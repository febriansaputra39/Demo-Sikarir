import { useState, useEffect, useContext } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { NotificationContext } from '../../contexts/NotificationContext';
import { parseRupiahInput, formatRupiah } from '../../utils/formatNumber';
import { User, Mail, Phone, MapPin, Briefcase, DollarSign, Save } from 'lucide-react';

export function Profil() {
  const { user, updateProfile } = useAuth();
  const notify = useContext(NotificationContext);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    headline: '',
    location: '',
    bio: '',
    targetGaji: '',
    statusKarir: 'Bekerja'
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || '',
        email: user.email || '',
        phone: user.phone || '',
        headline: user.headline || '',
        location: user.location || '',
        bio: user.bio || '',
        targetGaji: user.targetGaji || '',
        statusKarir: user.statusKarir || 'Bekerja'
      });
    }
  }, [user]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSalaryChange = (e) => {
    const numeric = parseRupiahInput(e.target.value);
    setFormData((prev) => ({ ...prev, targetGaji: numeric }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateProfile(formData);
      notify?.success('Profil pribadi Anda berhasil diperbarui!');
    } catch {
      notify?.error('Gagal memperbarui profil.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto' }}>
      <div style={{ marginBottom: '24px' }}>
        <h1 style={{ fontSize: '1.65rem', fontWeight: 800, color: '#0f172a' }}>
          Profil Saya
        </h1>
        <p style={{ color: '#64748b', fontSize: '0.88rem' }}>
          Informasi ini digunakan dalam resume CV ATS dan kalkulasi kecocokan algoritma Smart Matching.
        </p>
      </div>

      <div className="card">
        {/* Avatar banner */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '20px', marginBottom: '28px', paddingBottom: '20px', borderBottom: '1px solid #e2e8f0' }}>
          <img
            src={user?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
            alt="Avatar"
            style={{ width: '80px', height: '80px', borderRadius: '50%', objectFit: 'cover', border: '3px solid #e0e7ff' }}
          />
          <div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>{formData.name || 'Nama Kandidat'}</h3>
            <div style={{ color: '#4f46e5', fontWeight: 600, fontSize: '0.9rem' }}>{formData.headline || 'Spesialisasi Karir'}</div>
            <div style={{ fontSize: '0.78rem', color: '#64748b', marginTop: '4px' }}>{formData.email}</div>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-2">
            <div className="form-group">
              <label className="form-label">Nama Lengkap & Gelar</label>
              <input
                type="text"
                name="name"
                className="form-input"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Headline Profesional</label>
              <input
                type="text"
                name="headline"
                className="form-input"
                placeholder="Contoh: Frontend Developer & UI Specialist"
                value={formData.headline}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="grid grid-cols-2">
            <div className="form-group">
              <label className="form-label">Nomor WhatsApp / HP</label>
              <input
                type="text"
                name="phone"
                className="form-input"
                placeholder="08123456789"
                value={formData.phone}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Kota Domisili</label>
              <input
                type="text"
                name="location"
                className="form-input"
                placeholder="Jakarta Selatan, DKI Jakarta"
                value={formData.location}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="grid grid-cols-2">
            <div className="form-group">
              <label className="form-label">Status Penyerapan Karir Saat Ini</label>
              <select
                name="statusKarir"
                className="form-select"
                value={formData.statusKarir}
                onChange={handleChange}
              >
                <option value="Bekerja">Sudah Bekerja</option>
                <option value="Magang">Program Magang</option>
                <option value="Pelatihan">Sedang Pelatihan</option>
                <option value="Menganggur">Belum Bekerja / Mencari Peluang</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Ekspektasi Gaji Bulanan</label>
              <input
                type="text"
                className="form-input"
                placeholder="Contoh: Rp 9.000.000"
                value={formData.targetGaji ? formatRupiah(formData.targetGaji) : ''}
                onChange={handleSalaryChange}
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Ringkasan Pribadi (Bio Profesional)</label>
            <textarea
              name="bio"
              className="form-textarea"
              rows={4}
              placeholder="Ceritakan latar belakang kompetensi, keahlian utama, dan motivasi karir Anda..."
              value={formData.bio}
              onChange={handleChange}
            />
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '24px' }}>
            <button type="submit" disabled={loading} className="btn btn-primary">
              <Save size={16} />
              <span>{loading ? 'Menyimpan...' : 'Simpan Perubahan'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Profil;
